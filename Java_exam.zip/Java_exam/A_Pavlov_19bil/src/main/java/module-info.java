module com.example.a_pavlov_19bil {
    requires javafx.controls;
    requires javafx.fxml;
            
        requires org.controlsfx.controls;
            requires com.dlsc.formsfx;
                    requires org.kordamp.bootstrapfx.core;
                requires com.almasb.fxgl.all;
    
    opens com.example.a_pavlov_19bil to javafx.fxml;
    exports com.example.a_pavlov_19bil;
}