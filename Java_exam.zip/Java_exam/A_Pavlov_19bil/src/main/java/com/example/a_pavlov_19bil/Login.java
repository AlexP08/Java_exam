package com.example.a_pavlov_19bil;

import javafx.beans.property.SimpleStringProperty;

/**
 * Сущность для логина
 * @author Alexander Pavlov
 */

public class Login {

    private Long id;
    private String usrLogin;
    private String Password;

    public Login() {}

    public SimpleStringProperty Login(String usrLogin, String Password) {
        this.usrLogin = usrLogin;
        this.Password = Password;



        public void setRouteNumber(String usrLogin) {
            this.usrLogin = usrLogin;
        }

        /**
         * Возвращает SimpleStringProperty для логина пользователя
         * @return SimpleStringProperty
         */
        public SimpleStringProperty getUsrLoginProperty() {
            return new SimpleStringProperty(usrLogin);
        }

        /**
         * Возвращает SimpleStringProperty для пароля пользователя
         * @return SimpleStringProperty
         */
        public SimpleStringProperty getPasswordProperty(){
            return new SimpleStringProperty(Password);
        }



    }
}
