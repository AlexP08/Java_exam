package com.example.a_pavlov_19bil;

import com.example.a_pavlov_19bil.App;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

/**
 * контроллер сцены JavaFX
 * @author Alexander Pavlov
 */
public class LoginController {

    private App main;
    private Stage stage;

    /**
     * Инициализатор класса
     */
    public LoginController() {
    }

    /**
     * Устанавливает значение параметру main
     *
     * @param main App
     */
    public void setMain(App main) {
        this.main = main;
    }

    /**
     * Устанавливает значение параметру stage
     *
     * @param stage Stage
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void onLogButtonClick(ActionEvent actionEvent) {
    }
}