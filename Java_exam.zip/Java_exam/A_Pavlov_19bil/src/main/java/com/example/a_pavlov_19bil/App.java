package com.example.a_pavlov_19bil;

import com.example.a_pavlov_19bil.LoginController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Запускаемое приложение и контроллер сцены JavaFX
 * @author Alexander Pavlov
 */
public class App extends Application {

    private Stage primaryStage;
    private AnchorPane anchorPane;
    private BorderPane rootLayout;

    /**
     * возвращает значение параметра primaryStage
     *
     * @return Stage
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    /**
     * возвращает значение параметра anchorPane
     *
     * @return AnchorPane
     */
    public AnchorPane getAnchorPane() {
        return anchorPane;
    }

    /**
     * возвращает значение параметра return rootLayout;
     *
     * @return BorderPane
     */
    public BorderPane getRootLayout() {
        return rootLayout;
    }

    /**
     * инициализирует стартовое окно
     */
    public void initLogin() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(App.class.getResource("views/login.fxml"));
            anchorPane = loader.load();
            LoginController loginController = loader.getController();
            loginController.setMain(this);
            Scene scene = new Scene((anchorPane));
            primaryStage.setScene(scene);
            loginController.setStage(primaryStage);
            primaryStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Запускает показ интерфейса
     *
     * @param primaryStage Stage
     */
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("ReadMe");

        initLogin();
    }
}